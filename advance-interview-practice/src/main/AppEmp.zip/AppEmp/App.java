import model.Employee;
import model.Input;

import java.util.ArrayList;
import java.util.List;

public class App {

    public static void main(String[] args) {
        List<Input> inputList = new ArrayList<>();

        inputList.add(new Input(2, "Ratan Tata", null, "Mumbai"));
        inputList.add(new Input(3, "Gautam Adani", 2, "Ahmedabad"));
        inputList.add(new Input(4, "Mukesh Ambani", 3, "Mumbai"));
        inputList.add(new Input(5, "L. N. Mittal", 2, "London"));
        inputList.add(new Input(6, "Cyrus Poonawalla", 4, "Pune"));

        EmpService empService = new EmpService();
        empService.addEmployees(inputList);
        Employee ceo = empService.updateCEO();
        System.out.println(ceo.getName());

        System.out.println(empService.maxDepth());

        List<Employee> managers  = empService.getAllManagers();
        print(managers);

    }
    static void print(List<Employee> employees){
        for( Employee emp :employees){
            System.out.println(emp.getName());
        }
    }

}
//hr@interviewvector.com
//Subj : Omprakash Yadav|Dunzo|SSE 1|Live Coding (90 Mins)
